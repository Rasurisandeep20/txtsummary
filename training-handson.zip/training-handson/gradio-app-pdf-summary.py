import gradio as gr
from pdfsummarizer import get_pdf_summary
app=gr.Interface(
    inputs=["text"],
    outputs=["text"],
    fn=get_pdf_summary)
app.launch(share=True)
