import gradio as gr
app=gr.Interface(inputs=["text"], outputs=["number"], fn=len)
app.launch(share=True)
