import gradio as gr
def square(number):
    return number * number
app=gr.Interface(
    inputs=["number"],
    outputs=["number"],
    fn=square)
app.launch(share=True)
