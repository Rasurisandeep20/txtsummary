
from langchain_openai import OpenAI

llm = OpenAI(openai_api_key = "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")

print(llm.invoke('Tell me a joke'))




