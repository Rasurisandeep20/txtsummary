
from langchain_openai import OpenAI

llm = OpenAI()

print(llm.invoke('Tell me a joke'))




