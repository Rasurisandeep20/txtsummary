#!/usr/bin/env python


from langchain_community.document_loaders import PyPDFLoader
from langchain.chains import load_summarize_chain
from langchain_openai import ChatOpenAI



import os
os.environ["OPENAI_API_KEY"]


llm=ChatOpenAI()

pdf_file_path = "baahubali.pdf"
loader = PyPDFLoader(pdf_file_path)
docs = loader.load_and_split()

chain = load_summarize_chain(llm, chain_type="map_reduce",verbose=False)

summary = chain.invoke(docs)
print(summary.get('output_text'))



