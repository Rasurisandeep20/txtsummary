from langchain_community.document_loaders import PyPDFLoader
from langchain.chains import load_summarize_chain
from langchain_openai import ChatOpenAI

llm=ChatOpenAI()
def get_pdf_summary(pdffile):
    loader = PyPDFLoader(pdffile)
    docs = loader.load_and_split()
    chain = load_summarize_chain(llm, chain_type="map_reduce",verbose=False)
    summary = chain.invoke(docs)
    return summary.get('output_text')
